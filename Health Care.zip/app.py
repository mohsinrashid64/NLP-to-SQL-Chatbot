import streamlit as st
import pandas as pd
import sqlite3
import re

from langchain_community.llms import Ollama
from langchain_community.utilities import SQLDatabase
from langchain.chains import create_sql_query_chain
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# ------------------------
# Setup
# ------------------------
st.set_page_config(page_title="SQL + AI Analyst", layout="wide")

st.title("🔍 AI SQL Query & Analysis App")

# Upload database
db_file = st.file_uploader("Upload your SQLite database", type=["db", "sqlite"])
if db_file:
    with open("temp.db", "wb") as f:
        f.write(db_file.read())
    conn = sqlite3.connect("temp.db")
    db = SQLDatabase.from_uri("sqlite:///temp.db")

    # ✅ Use Ollama instead of OpenAI
    llm = Ollama(model="llama3.2", temperature=0)

    st.success("✅ Database connected!")

    # ------------------------
    # Query Section
    # ------------------------
    st.subheader("Step 1: Query your database")
    user_question = st.text_area("Enter your question in plain English")

    if st.button("Run Query"):
        if user_question.strip():
            query_chain = create_sql_query_chain(llm, db)
            raw_sql = query_chain.invoke({"question": user_question})

            # Extract only SQL
            match = re.search(r"(?i)select.+", raw_sql, re.DOTALL)
            if match:
                clean_sql = match.group(0).strip()
                st.code(clean_sql, language="sql")

                try:
                    df = pd.read_sql_query(clean_sql, conn)
                    st.dataframe(df, use_container_width=True)

                    st.session_state["last_result"] = df
                    st.session_state["last_question"] = user_question

                except Exception as e:
                    st.error(f"SQL Execution Error: {e}")
            else:
                st.error("❌ No valid SQL found in LLM output.")
    
    # ------------------------
    # Analysis Section
    # ------------------------
    if "last_result" in st.session_state:
        st.subheader("Step 2: Analyze Results")
        analysis_question = st.text_area("Enter analysis prompt")

        if st.button("Run Analysis"):
            analysis_prompt = PromptTemplate.from_template("""
            You are a data analyst. Here is the SQL result in table format:

            {data}

            User's original question: {question}
            Now the user asks: {analysis_question}

            Provide a clear and concise analysis.
            """)

            analysis_chain = LLMChain(llm=llm, prompt=analysis_prompt)

            analysis = analysis_chain.run(
                data=st.session_state["last_result"].to_dict(orient="records"),
                question=st.session_state["last_question"],
                analysis_question=analysis_question
            )

            st.write("### 📊 Analysis")
            st.write(analysis)

else:
    st.info("👆 Upload a SQLite database to get started.")
